﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.utilities.entities
{
    // класс для вывода в грид запросов
    public class RequestGrid
    {
        public int id { get; set; }
        public string address { get; set; }
        public string housemate { get; set; }
        public string description { get; set; }
        public string date { get; set; }
        public string worker { get; set; }
        public string status { get; set; }
    }
}
