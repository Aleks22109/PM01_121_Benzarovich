﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace WpfApp1.pages.AddEditPage
{
    /// <summary>
    /// Логика взаимодействия для AddEditRequest.xaml
    /// </summary>
    public partial class AddEditRequest : Page
    {

        // храним для передачи и взаимодействия айди запроса
        private int requestId;

        public AddEditRequest(int requestId = -1)
        {
            InitializeComponent();
            this.requestId = requestId;

            // проверяем если айди больше или равен 0, то запрос существующий
            if (requestId >= 0)
            {
                requests request;
                using (var context = new BdEntities())
                {
                    request = context.requests.First(ch => ch.id ==  requestId);
                }
                AddressBox.SelectedItem = getAddressNameById(request.address_id);
                housemateBox.SelectedItem = getHousemateNameById(request.housemate_id);
                descriptionBlock.Text = request.description;
                DateBox.SelectedDate = request.date;
                workerBox.SelectedItem = getWorkerNameById(request.worker_id);
                StatusBox.SelectedItem = getStatusNameById(request.request_id);

                infoText.Text = "Изменение запроса";
            }
            // иначе создается новый
            else
            {
                infoText.Text = "Добавление запроса";
            }

            // заполнение комбо боксов данными
            AddressBox.ItemsSource = getAddresses();
            housemateBox.ItemsSource = getHouseMates();
            workerBox.ItemsSource = getWorkers();
            StatusBox.ItemsSource = getRequestStatuses(); 
        }

        // кнопка назад
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            if (NavigationService.CanGoBack)
            {
                NavigationService.GoBack();
            }
        }

        // методы получения данных для комбобоксов
        private static string[] getAddresses()
        {
            using (var context = new BdEntities())
            {
                return context.addresses.Select(ch => ch.street).ToArray();
            }
        }

        private static string[] getHouseMates()
        {
            using (var context = new BdEntities())
            {
                return context.housemates.Select(ch => ch.FIO).ToArray();
            }
        }
        private static string[] getWorkers()
        {
            using (var context = new BdEntities())
            {
                return context.workers.Select(ch => ch.FIO).ToArray();
            }
        }
        private static string[] getRequestStatuses()
        {
            using (var context = new BdEntities())
            {
                return context.request_types.Select(ch => ch.name).ToArray();
            }
        }


        // метод подтверждения
        private void Confirm_Click(object sender, RoutedEventArgs e)
        {
            // если запрос = -1 -> создание
            if (requestId == -1)
            {
                // проверка данных
                if (AddressBox.SelectedItem == null || String.IsNullOrEmpty(AddressBox.SelectedItem.ToString()) == true)
                {
                    MessageBox.Show("Выберите адрес!", "Добавление запроса");
                    return;
                }
                if (housemateBox.SelectedItem == null || String.IsNullOrEmpty(housemateBox.SelectedItem.ToString()) == true)
                {
                    MessageBox.Show("Выберите жителя!", "Добавление запроса");
                    return;
                }
                if (String.IsNullOrEmpty(descriptionBlock.Text) == true || descriptionBlock.Text.Length < 10)
                {
                    MessageBox.Show("Опишите проблему!", "Добавление запроса");
                    return;
                }
                if (DateBox.SelectedDate == null)
                {
                    MessageBox.Show("Выберите дату!", "Добавление запроса");
                    return;
                }
                if (workerBox.SelectedItem == null || String.IsNullOrEmpty(workerBox.SelectedItem.ToString()) == true)
                {
                    MessageBox.Show("Выберите работника!", "Добавление запроса");
                    return;
                }
                if (StatusBox.SelectedItem == null || String.IsNullOrEmpty(StatusBox.SelectedItem.ToString()) == true)
                {
                    MessageBox.Show("Выберите статус!", "Добавление запроса");
                    return;
                }

                // добавляем в бд
                requests request = new requests
                {
                    address_id = getAddressIdByName(AddressBox.SelectedItem.ToString()),
                    housemate_id = getHousemateIdByName(housemateBox.SelectedItem.ToString()),
                    description = descriptionBlock.Text,
                    date = DateBox.SelectedDate,
                    worker_id = getWorkerIdByName(workerBox.SelectedItem.ToString()),
                    request_id = getStatusIdByName(StatusBox.SelectedItem.ToString())
                };
                using (var context = new BdEntities())
                {
                    context.requests.Add(request);
                    context.SaveChanges();
                }
            }
            // иначе изменяем существующий
            else
            {
                // проверка данных
                if (String.IsNullOrEmpty(descriptionBlock.Text) == true || descriptionBlock.Text.Length < 10)
                {
                    MessageBox.Show("Опишите проблему!", "Добавление запроса");
                    return;
                }

                // изменяем данные
                using (var context = new BdEntities())
                {
                    requests currentRequest = context.requests.First(ch => ch.id == requestId);
                    currentRequest.address_id = getAddressIdByName(AddressBox.SelectedItem.ToString());
                    currentRequest.housemate_id = getHousemateIdByName(housemateBox.SelectedItem.ToString());
                    currentRequest.description = descriptionBlock.Text;
                    currentRequest.date = DateBox.SelectedDate;
                    currentRequest.worker_id = getWorkerIdByName(workerBox.SelectedItem.ToString());
                    currentRequest.request_id = getStatusIdByName(StatusBox.SelectedItem.ToString());
                    context.SaveChanges();
                }
            }
            NavigationService.Navigate(new RequestPage());
        }

        // методы получения айди по названию
        private static int getAddressIdByName(string name)
        {
            using (var context = new BdEntities())
            {
                return context.addresses.First(ch => ch.street == name).id;
            }
        }

        private static int getHousemateIdByName(string name)
        {
            using (var context = new BdEntities())
            {
                return context.housemates.First(ch => ch.FIO == name).id;
            }
        }

        private static int getWorkerIdByName(string name)
        {
            using (var context = new BdEntities())
            {
                return context.workers.First(ch => ch.FIO == name).id;
            }
        }

        private static int getStatusIdByName(string name)
        {
            using (var context = new BdEntities())
            {
                return context.request_types.First(ch => ch.name == name).id;
            }
        }


        // методы получения названия по айди
        private static string getAddressNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.addresses.First(ch => ch.id == id).street;
            }
        }

        private static string getHousemateNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.housemates.First(ch => ch.id == id).FIO;
            }
        }

        private static string getWorkerNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.workers.First(ch => ch.id == id).FIO;
            }
        }

        private static string getStatusNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.request_types.First(ch => ch.id == id).name;
            }
        }
    }
}
